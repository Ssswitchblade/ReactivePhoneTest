import UIKit
import Foundation

func updateMatrix(_ matrix: [[Int]]) -> [[Int]] {
    let m = matrix.count
    let n = matrix[0].count
    var distance = Array(repeating: Array(repeating: Int.max-10000, count: n), count: m)
    
    for i in 0..<m {
        for j in 0..<n {
            if matrix[i][j] == 0 {
                if i > 0 {
                    distance[i][j] = min(distance[i][j], distance[i-1][j]+1)
                }
                if j > 0 {
                    distance[i][j] = min(distance[i][j], distance[i][j-1]+1)
                }
            } else {
                distance[i][j] = 0
            }
        }
    }
    
    for i in stride(from: m-1, through: 0, by: -1) {
        for j in stride(from: n-1, through: 0, by: -1) {
            if matrix[i][j] == 0 {
                if i < m-1 {
                    distance[i][j] = min(distance[i][j], distance[i+1][j]+1)
                }
                if j < n-1 {
                    distance[i][j] = min(distance[i][j], distance[i][j+1]+1)
                }
            }
        }
    }
    return distance
}

print(updateMatrix([[1,0,1],
              [0,1,0],
              [0,0,0]]))
